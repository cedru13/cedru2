#!/bin/bash
EXEC_NAME="eloword"

echo $(date +%s) > "/tmp/miner_start_time"

echo $MINER_LOG_BASENAME.log

echo "Starting Mining instance..."
"$EXEC_NAME"
